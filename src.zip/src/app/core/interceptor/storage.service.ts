import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { AnyRecord } from 'dns';
const SecureStorage = require('secure-web-storage');
const SECRET_KEY: any = 'Y7J82,Lf^KwM@v?&X&q3bcF';
declare var require: any;

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  constructor() {}

  secureStorage = new SecureStorage(sessionStorage, {
    hash: function hash(key: any) {
      key = CryptoJS.SHA256(key, SECRET_KEY);
      return key.toString();
    },

    // Encrypt the localstorage data
    encrypt: function encrypt(data: any) {
      data = CryptoJS.AES.encrypt(data, SECRET_KEY);
      data = data.toString();
      return data;
    },

    // Decrypt the encrypted data
    decrypt: function decrypt(data: any) {
      data = CryptoJS.AES.decrypt(data, SECRET_KEY);
      data = data.toString(CryptoJS.enc.Utf8);
      return data;
    },
  });

  public setRoles(roles: []) {
    return this.secureStorage.setItem('roles', roles);
  }

  public getRoles() {
    return this.secureStorage.getItem('roles');
  }

  public setToken(jwtToken: any) {
    return this.secureStorage.setItem('jwtToken', jwtToken);
  }

  public getToken(): string {
    return this.secureStorage.getItem('jwtToken');
  }

  public getuser(): string {
    return this.secureStorage.getItem('username');
  }

  public setusername(username: any) {
    return this.secureStorage.setItem('username', username);
  }

  public clear() {
    return this.secureStorage.clear();
  }

  public variable(data: any) {
    return this.secureStorage.setItem('alldata', data);
  }

  public getvariable(): string {
    return this.secureStorage.getItem('alldata');
  }

  public isLoggedIn() {
    return this.getRoles() && this.getToken() && this.getuser();
  }
}
