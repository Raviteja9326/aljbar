import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  DoCheck,
  HostListener,
  OnInit,
} from '@angular/core';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
declare let $: any;
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { SearchComponent } from '../search/search.component';
import { MatDialog } from '@angular/material/dialog';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { AdminService } from 'src/app/services/admin.service';
import { takeUntil } from 'rxjs/operators';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements OnInit, AfterViewInit {
  names: any;
  type: any;
  destroy$: Subject<boolean> = new Subject<boolean>();
  lang: any;
  scrolldown: boolean;
  selectedChoice: any;
  city: string;
  count: number;
  bellshow: boolean = false;
  errmsgdisplay: string;
  errmsg: boolean;
  new: number = 0;
  wfq: number = 0;
  wfa: number = 0;
  wfp: number = 0;
  wfaa: number = 0;
  wfap: number = 0;
  wip: number = 0;
  rfd: number = 0;
  dlvd: number = 0;
  totalcount:any = 0;

  constructor(
    private useservice: AllinoneService,
    private store: StorageService,
    private loginout: LoginService,
    private admin: AdminService,
    private translateService: TranslateService,
    private router: Router,
    public dialog: MatDialog,
    private cdRef: ChangeDetectorRef,
    public ischeck: LoginService
  ) {
    this.mylang();
    this.namescity();
    this.senddata();
  }

  ngAfterViewInit(): void {
    this.blurimg();
    this.cdRef.detectChanges();
  }

  blurimg() {
    this.useservice.blurbg.subscribe((res) => {
      this.selectedChoice = res;
    });
  }

  namescity() {
    if (
      this.store.getuser() != 'NA' ||
      this.store.getuser() != undefined ||
      this.store.getvariable() != 'NA' ||
      this.store.getvariable() != undefined ||
      this.store.getRoles() != 'NA' ||
      this.store.getRoles() != undefined
    ) {
      this.names = this.store.getuser();
      this.type = this.store.getRoles();
      this.city = this.store.getvariable();
      setInterval(() => {
        this.senddata();
      }, 60000);
    } else {
      this.names = 'welcome';
      this.type = '';
    }
  }

  mylang() {
    this.useservice.sendlanguage.subscribe((res) => {
      console.log(res);
      if (res == 'en') {
        this.lang = 'en';
        this.translateService.use('en').toPromise();
        this.translateService.setDefaultLang('en');
      } else if (res == 'ar') {
        this.lang = 'ar';
        this.translateService.use('ar').toPromise();
        this.translateService.setDefaultLang('ar');
      }
    });
  }

  useLanguage(language) {
    this.lang = language;
    this.useservice.changlang(language);
    this.translateService.use(language).toPromise();
  }

  ngOnInit(): void {
    this.jquremethod();
    this.blurimg();
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  @HostListener('window:scroll', ['$event'])
  getScrollHeight(event: any) {
    if (window.pageYOffset > 1) {
      $('.top-navbar').addClass('is-sticky');
    } else {
      $('.top-navbar').removeClass('is-sticky');
    }
  }

  playAudio() {
    let audio = new Audio();
    audio.src = '../../../assets/img/sound.wav';
    audio.load();
    audio.play();
  }

  openCompaniesModal8(reloaddata): void {
    console.log(reloaddata);
    var data: boolean = true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: '100%',
      data: { dat22: reloaddata, name22: data },
      disableClose: true,
      position: {
        top: '20px',
      },
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      console.log('The dialog was closed');
    });
  }


  senddata() {
    this.errmsg = false;
    const keys: any = {};
    keys['city'] = this.store.getvariable();
    this.admin
      .GetnotificationList(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008')
        {
            this.new = data.new;
            this.wfq = data.wfq;
            this.wfa = data.wfa;
            this.wfp = data.wfp;
            this.wfaa = data.wfaa;
            this.wfap = data.wfap;
            this.wip = data.wip;
            this.rfd = data.rfd;
            this.dlvd = data.dld;
            this.totalcount = +this.new+ +this.wfq+ +this.wfa+ +this.wfaa+ +this.wfp+ +this.wfap+ +this.wip+ +this.rfd+ +this.dlvd
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.loginout.usersession8();
        } else if (data['status'] == '1070' && data['tokenStatus'] == '1008') {
          this.errmsg = true;
          this.errmsgdisplay = 'no record found';
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          this.errmsg = true;
        }
      });
  }

  jquremethod() {
    $('.burger-menu').on('click', () => {
      $(this).toggleClass('active');
      $('.main-content').toggleClass('hide-sidemenu-area');
      $('.sidemenu-area').toggleClass('toggle-sidemenu-area');
      $('.top-navbar').toggleClass('toggle-navbar-area');
    });
    $('.responsive-burger-menu').on('click', function () {
      $('.responsive-burger-menu').toggleClass('active');
      $('.sidemenu-area').toggleClass('active-sidemenu-area');
    });
    $(function () {
      $('[data-toggle="tooltip"]').tooltip();
    });
    $(function () {
      $('[data-toggle="popover"]').popover();
    });
    $(function () {
      $('#sidemenu-nav').metisMenu();
    });
    $('.bx-fullscreen-btn').on('click', () => {
      $(this).toggleClass('active');
    });
    $(function () {
      $('.accordion')
        .find('.accordion-title')
        .on('click', function () {
          $(this).toggleClass('active');
          $(this).next().slideToggle('fast');
          $('.accordion-content').not($(this).next()).slideUp('fast');
          $('.accordion-title').not($(this)).removeClass('active');
        });
    });
    (function ($) {
      $('.tab ul.tabs')
        .addClass('active')
        .find('> li:eq(0)')
        .addClass('current');
      $('.tab ul.tabs li a').on('click', function (g) {
        var tab = $(this).closest('.tab'),
          index = $(this).closest('li').index();
        tab.find('ul.tabs > li').removeClass('current');
        $(this).closest('li').addClass('current');
        tab
          .find('.tab_content')
          .find('div.tabs_item')
          .not('div.tabs_item:eq(' + index + ')')
          .slideUp();
        tab
          .find('.tab_content')
          .find('div.tabs_item:eq(' + index + ')')
          .slideDown();
        g.preventDefault();
      });
    });
  }

  logout() {
    this.loginout.usersession8();
  }
}
