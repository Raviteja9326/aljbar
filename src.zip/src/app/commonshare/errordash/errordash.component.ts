import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { AllinoneService } from 'src/app/services/allinone.service';

@Component({
  selector: 'app-errordash',
  templateUrl: './errordash.component.html',
  styleUrls: ['./errordash.component.scss'],
})
export class ErrordashComponent implements OnInit {
  constructor(
    private dialogRef: MatDialog,
    private ngxLoader: NgxUiLoaderService,
    private getid: AllinoneService
  ) {}

  ngOnInit(): void {
    this.ngxLoader.stopAll();
    this.dialogRef.closeAll();
    this.getid.setblur('noblur');
  }
}
