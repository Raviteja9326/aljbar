import { ChangeDetectorRef, Component, ElementRef, HostListener, Inject, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { AllinoneService } from 'src/app/services/allinone.service';
import {ENTER, COMMA, F} from '@angular/cdk/keycodes';
import Swal from 'sweetalert2';
import { MatChipInputEvent } from '@angular/material/chips';
import { AdminService } from 'src/app/services/admin.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { LoginService } from 'src/app/services/login.service';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { config } from 'src/app/config/api.config';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
})
export class SearchComponent implements OnInit {
  url: any = config;
  destroy$: Subject<boolean> = new Subject<boolean>();
  alldata: any;
  datafound: boolean;
  errmsg: boolean;
  selectcity: boolean;
  selecttype: boolean;
  page: any = 0;
  errmsgdisplay: string;
  city: any;
  subbtn: boolean = false;
  profall: any;
  status: any;
  assignpend: string;
  panelOpenState = false;
  Object = Object;
  price1 = [];
  price2 = [];
  price3: any[];
  sum = 0;
  percent: number;
  totalamount: number;
  allvechile: any;

  constructor(
    private ngxLoader: NgxUiLoaderService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private useservice: AllinoneService,
    private logins: LoginService,
    private admin: AdminService,
    private store: StorageService,
    public dialogRef: MatDialogRef<SearchComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any = [],
    private cd: ChangeDetectorRef
  ) {
    this.ngxLoader.stopAll();
  }

  form = this.formBuilder.group({
    bookingStatus: new FormControl('', [Validators.required]),
  });
  get Controllers() {
    return this.form.controls;
  }

  onCancel() {
    this.dialogRef.close({ data: this.status });
  }

  onCancel2() {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.useservice.setblur('blur');
    if (this.data.workshop_bool == true) {
      this.city = this.data.workshop.city;
      this.status = this.data.workshop.bookingStatus;
      this.getcity(this.data.workshop.city);
    } else if (this.data.assignwork_bool == true) {
      this.status = this.data.assignwork;
      this.getvehicle();
    } else if (this.data.assignwork_register_bool == true) {
      this.status = this.data.mobile_no;
      this.getvehicle();
    } else if (this.data.invoicedetails_bool == true) {
      this.alldata = this.data.invoicedetails;
      this.estimatamount();
    }
  }

  async estimatamount() {
    for (let obj of this.alldata.estimationSubCatTypePrices) {
      this.price1.push(obj.price);
    }
    for (let obj2 of this.alldata.addOns) {
      this.price2.push(obj2.price);
    }
    this.price3 = this.price1.concat(this.price2);
    const data = JSON.parse('[' + this.price3.join() + ']');
    for (let i = 0; i < data.length; i++) {
      this.sum += data[i];
    }
    this.percent = (15 * this.sum) / 100;
    this.totalamount = this.sum + +this.percent;
  }

  getvehicle() {
    this.datafound = false;
    this.errmsg = false;
    this.ngxLoader.start();
    const keys: any = {};
    keys['type'] = 'NOTASSIGNED';
    this.admin
      .Getvehiclelist(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1069' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.datafound = true;
          this.alldata = data.vehicleDetails;
        } else if (data['status'] == '1070') {
          this.alldata = [];
          this.errmsg = true;
          this.datafound = false;
          this.errmsgdisplay = 'data not available';
          this.ngxLoader.stop();
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.ngxLoader.stop();
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
        }
      });
  }

  getcity(obj) {
    this.datafound = false;
    this.errmsg = false;
    this.ngxLoader.start();
    const keys: any = {};
    keys['pageNumber'] = this.page.toString();
    keys['pageSize'] = '2000';
    keys['deviceId'] = this.useservice.visitorId;
    keys['city'] = obj;
    this.admin
      .citiesList(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1069' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.datafound = true;
          this.alldata = data.workshopsList;
        } else if (data['status'] == '1070') {
          this.alldata = [];
          this.errmsg = true;
          this.datafound = false;
          this.errmsgdisplay = 'data not available';
          this.ngxLoader.stop();
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
        }
      });
  }

  submit(obj: any, item: any) {
    const data = this.alldata.filter((res: any) => {
      return res.wsId == item.wsId;
    });
    if (obj == true) {
      this.alldata = data;
      this.subbtn = true;
      this.profall = item.wsId.toString();
    } else if (obj == false) {
      this.subbtn = false;
      this.getcity(this.data.workshop.city);
    }
  }

  submit2(obj: any, item: any) {
    const data = this.alldata.filter((res: any) => {
      return res.cabId == item.cabId;
    });
    if (obj == true) {
      this.alldata = data;
      this.subbtn = true;
      this.profall = item.cabId.toString();
      this.allvechile = item
    } else if (obj == false) {
      this.allvechile = "";
      this.subbtn = false;
      this.getvehicle();
    }
  }

  newsubmit5()
  {
    if (this.allvechile == '' || this.allvechile == undefined) {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 4000,
      });
      Toast.fire({
        icon: 'warning',
        title: `Please select vehicle to assign driver`,
      });
    } else if (this.allvechile != '' || this.allvechile == undefined)
    {
      this.dialogRef.close({ data: this.allvechile });
    }
  }

  newsubmit() {
    this.datafound = false;
    this.errmsg = false;
    this.ngxLoader.start();
    const keys: any = {};
    keys['bookingId'] = this.data.workshop.bookingId;
    keys['bookingStatus'] = 'WAITING_FOR_QUOTATION';
    keys['professionalId'] = this.profall;
    keys['deviceId'] = this.useservice.visitorId;
    this.admin
      .updateList(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.datafound = true;
          Swal.fire(
            'Request Assigned To Workshop, Awaiting Quotation',
            '',
            'success'
          );
          this.onCancel();
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.subbtn = false;
          this.ngxLoader.stop();
        }
      });
  }

  newsubmit2() {
    this.datafound = false;
    this.errmsg = false;
    this.ngxLoader.start();
    const keys: any = {};
    keys['mobile'] = this.status.toString();
    keys['vehicleId'] = this.profall.toString();
    keys['deviceId'] = this.useservice.visitorId;
    this.admin
      .assignVehicle(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.datafound = true;
          Swal.fire('Vehicle Assigned To Driver', '', 'success');
          this.onCancel2();
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.subbtn = false;
          this.ngxLoader.stop();
        }
      });
  }

  newsubmit3() {
    this.datafound = false;
    this.errmsg = false;
    this.ngxLoader.start();
    const keys: any = {};
    keys['mobile'] = this.status.toString();
    keys['vehicleId'] = this.profall.toString();
    keys['deviceId'] = this.useservice.visitorId;
    this.admin
      .reassignVehicle(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.datafound = true;
          Swal.fire('Vehicle Assigned To Driver Successfully', '', 'success');
          this.onCancel2();
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.subbtn = false;
          this.ngxLoader.stop();
        }
      });
  }
}