import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss'],
})
export class WelcomeComponent implements OnInit {
  names: string;
  type: any;
  city: string;
  constructor(
    private dialogRef: MatDialog,
    private ngxLoader: NgxUiLoaderService,
    private store: StorageService,
    private getid: AllinoneService
  ) {}

  ngOnInit(): void {
    this.namescity();
    this.ngxLoader.stopAll();
    this.dialogRef.closeAll();
    this.getid.setblur('noblur');
  }

  namescity() {
    if (
      this.store.getuser() != 'NA' ||
      this.store.getuser() != undefined ||
      this.store.getvariable() != 'NA' ||
      this.store.getvariable() != undefined ||
      this.store.getRoles() != 'NA' ||
      this.store.getRoles() != undefined
    ) {
      this.names = this.store.getuser();
      this.type = this.store.getRoles();
      this.city = this.store.getvariable();
    } else {
      this.names = 'welcome';
      this.type = '';
    }
  }
}
