import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-musllahadmin',
  template: `<router-outlet></router-outlet>`,
})
export class MusllahadminComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
