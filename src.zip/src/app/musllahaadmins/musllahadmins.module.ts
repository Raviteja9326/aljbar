import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MusllahadminsRoutingModule } from './musllahadmins-routing.module';
import { CreateadminsComponent } from './createadmins/createadmins.component';
import { AdminsComponent } from './admins/admins.component';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../commonshare/material.module';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';
import { TranslateModule } from '@ngx-translate/core';
import { MusllahadminComponent } from './musllahadmin.component';
import { TableModule } from 'primeng/table';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  declarations: [AdminsComponent, CreateadminsComponent, MusllahadminComponent],
  imports: [
    CommonModule,
    TableModule,
    InfiniteScrollModule,
    NgxPaginationModule,
    MusllahadminsRoutingModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgxMatMomentModule,
    SweetAlert2Module.forRoot(),
    TranslateModule,
  ],
})
export class MusllahadminsModule {}
