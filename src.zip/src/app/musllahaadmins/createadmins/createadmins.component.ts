import { Component, OnInit, OnDestroy } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

export function noWhitespaceValidator(control: FormControl) {
  const isSpace = (control.value || '').match(/\s/g);
  return isSpace ? { whitespace: true } : null;
}
export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
    control.setValue('');
    console.log(control.value);
    return { required: true };
  } else {
    return null;
  }
}

@Component({
  selector: 'app-createadmins',
  templateUrl: './createadmins.component.html',
  styleUrls: ['./createadmins.component.scss'],
})
export class CreateadminsComponent implements OnInit, OnDestroy {
  destroy$: Subject<boolean> = new Subject<boolean>();
  errmsg: boolean;
  errmsgdisplay: any;
  citys: any;
  fieldTextType: boolean = false;
  ip!: string;
  constructor(
    private ngxLoader: NgxUiLoaderService,
    private formBuilder: FormBuilder,
    private router: Router,
    private useservice: AllinoneService,
    private logins: LoginService,
    private admin: AdminService,
    private store: StorageService
  ) {
    this.useservice.setblur('noblur');
    this.ngxLoader.stopAll();
    this.useservice.ipaddress.subscribe((res) => {
      this.ip = res;
      console.log(this.ip);
    });
  }

  cityform = this.formBuilder.group({
    countryName: ['SaudiArabia'],
  });

  form = this.formBuilder.group({
    firstname: new FormControl('', [Validators.required]),
    lastname: new FormControl('', [Validators.required]),
    emailid: new FormControl('', [Validators.required]),
    userType: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    language: new FormControl('', [Validators.required]),
    cred: new FormControl('', [
      Validators.required,
      spaceValidator,
      Validators.minLength(8),
      Validators.maxLength(16),
      Validators.pattern(
        /^(?=.*\d)(?=.*[\~\!\@\#\$\%\^\&\*\)\(\_\+\-\:\[\}\=\"\`])(?=.*[a-z])(?=.*[A-Z]).{8,}$/
      ),
    ]),
  });

  get Controllers() {
    return this.form.controls;
  }

  ngOnInit(): void {
    this.city();
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  reset() {
    this.form.reset();
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  submit() {
    this.errmsg = false;
    this.useservice.setblur('blur');
    this.ngxLoader.start();
    const keys: any = {};
    keys['deviceId'] = this.useservice.visitorId;
    keys['iPAddress'] = this.ip;
    this.admin
      .registeradmin(this.form.value, keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'success',
            title: `Admin Successfully Registered`,
          });
          this.router.navigate(['/musllahaaljabr/adminslist']);
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
        }
      });
  }

  city() {
    this.errmsg = false;
    const keys: any = {};
    keys['type'] = 'GETCITES';
    keys['countryName'] = this.cityform.value.countryName;
    this.admin
      .GetcityList(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1069' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
          this.citys = data.cites_list;
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['status'] == '1070' && data['tokenStatus'] == '1008') {
          this.citys = [];
          this.useservice.setblur('noblur');
          this.ngxLoader.stop();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
        }
      });
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
