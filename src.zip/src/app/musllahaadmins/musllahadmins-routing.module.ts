import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from '../commonshare/welcome/welcome.component';
import { AdminsComponent } from './admins/admins.component';
import { CreateadminsComponent } from './createadmins/createadmins.component';
import { MusllahadminComponent } from './musllahadmin.component';

const routes: Routes = [
  {
    path: '',
    component: MusllahadminComponent,
    children: [
      {
        path: 'welcome',
        component: WelcomeComponent,
      },
      {
        path: 'adminslist',
        component: AdminsComponent,
      },
      {
        path: 'createadmins',
        component: CreateadminsComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MusllahadminsRoutingModule {}
