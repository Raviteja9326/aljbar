import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './commonshare/dashboard/dashboard.component';
import { ErrorComponent } from './commonshare/error/error.component';
import { ErrordashComponent } from './commonshare/errordash/errordash.component';
import { SearchComponent } from './commonshare/search/search.component';
import { AuthGuard } from './core/auth.guard';
import { LoginComponent } from './secure/login/login.component';
import { ResetpwdComponent } from './secure/resetpwd/resetpwd.component';
import { ForgotpasswdComponent } from './secure/forgotpasswd/forgotpasswd.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'reset', component: ForgotpasswdComponent },
  { path: 'forgot/:id', component: ResetpwdComponent },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {
    path: '',
    component: DashboardComponent,
    children: [
      { path: 'errors', component: ErrordashComponent },
      {
        path: 'aljabr',
        loadChildren: () =>
          import('./admin/admin.module').then((m) => m.AdminModule),
        canActivate: [AuthGuard],
      },
      {
        path: 'musllahaaljabr',
        loadChildren: () =>
          import('./musllahaadmins/musllahadmins.module').then(
            (m) => m.MusllahadminsModule
          ),
        canActivate: [AuthGuard],
      },
    ],
  },
  { path: 'error', component: ErrorComponent },
  { path: 'search', component: SearchComponent },
  // Fallback when no prior routes is matched
  { path: '**', redirectTo: '/error', pathMatch: 'full' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: true,
      relativeLinkResolution: 'legacy',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
