import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Observable, throwError } from 'rxjs';
import { catchError, retry, timeout } from 'rxjs/operators';
import { config } from '../config/api.config';
import { StorageService } from '../core/interceptor/storage.service';
import { AllinoneService } from './allinone.service';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  data: any;

  constructor(
    private httpClient: HttpClient,
    private details: AllinoneService,
    private router: Router,
    private ngxLoader: NgxUiLoaderService,
    private userAuthService: StorageService,
    private dialogRef: MatDialog
  ) {}

  useremaillogin(keys: any, Email: any, password: any): Observable<any> {
    const keys2 = Object.assign({}, keys, this.details.getResponse());
    let authorizationData = 'Basic ' + btoa(Email + ':' + password);
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: authorizationData,
      }),
    };
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/support/login/cred`, keys2, httpOptions)
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/error']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  updatepwd(keys: any, keys2: any): Observable<any> {
    const obj2 = Object.assign({}, keys, keys2, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/forget/paswword`, obj2)
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/error']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  resetpwd(keys: any, keys2: any): Observable<any> {
    const obj2 = Object.assign({}, keys, keys2, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/forget/update/paswword`, obj2)
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/error']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  usersession8() {
    this.ngxLoader.stop();
    this.dialogRef.closeAll();
    this.userAuthService.clear();
    this.router.navigate(['/login']);
  }

  usersession9() {
    this.ngxLoader.stop();
    this.userAuthService.clear();
    this.dialogRef.closeAll();
  }

  public roleMatch(allowedRoles: any): any {
    let isMatch = false;
    const userRoles: any = this.userAuthService.getRoles();

    if (userRoles != null && userRoles) {
      if (userRoles == allowedRoles) {
        isMatch = true;
        return isMatch;
      } else {
        return isMatch;
      }
    }
  }
}