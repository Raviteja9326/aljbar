import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AnyARecord } from 'dns';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Observable, throwError } from 'rxjs';
import { catchError, retry, timeout } from 'rxjs/operators';
import { config } from '../config/api.config';
import { StorageService } from '../core/interceptor/storage.service';
import { AllinoneService } from './allinone.service';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  requestHeader = new HttpHeaders({ 'No-Auth': 'True' });

  constructor(
    protected httpClient: HttpClient,
    private details: AllinoneService,
    private store: StorageService,
    private router: Router,
    private ngxLoader: NgxUiLoaderService
  ) {}

  GetserviceList(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/getrequests`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  GetnotificationList(keys: AnyARecord): Observable<any> {
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/requests/count`, keys, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  GetcityList(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/getcities`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  updateList(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/update/bookingstatus`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  updateList2(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/update/addonstatus`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  updateList3(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(
        `${config.apiBaseUrl}/aljabr/update/subcategory/status`,
        obj2,
        {
          headers: this.requestHeader,
        }
      )
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  updateList4(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/assignTo/manager`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  updateList5(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(
        `${config.apiBaseUrl}/aljabr/update/user/subcategorytype/status`,
        obj2,
        {
          headers: this.requestHeader,
        }
      )
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  driverdelete(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/delete/driver`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  deleteadmin(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/admin/delete`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  vehicledelete(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/deletevehicledetail`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  workshopdelete(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/delete/workshop`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  citiesList(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/getworkshops`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  Getraiderlist(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/sp/driver/getlist`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  Getpartnerlist(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(
        `${config.apiBaseUrl}/aljabr/get/partnerbooking/allList`,
        obj2,
        {
          headers: this.requestHeader,
        }
      )
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  Getinvoicelist(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/sp/pending/invoices/get`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  Getspreferrallist(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/sp/getrefferalcodes`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  Getsadminlist(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/admin/get`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  Getuserreferrallist(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/user/getrefferalcodes`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  Getescalationlist(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/get/escalatedList`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  Getvehiclelist(keys: any): Observable<any> {
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/getallvehicledetails`, keys, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  assignVehicle(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/user/vehicle/assignment`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  reassignVehicle(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(
        `${config.apiBaseUrl}/aljabr/user/vehicle/reassignment`,
        obj2,
        {
          headers: this.requestHeader,
        }
      )
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  deassignVehicle(keys: any): Observable<any> {
    const obj2 = Object.assign({}, keys, this.details.getResponse());
    return this.httpClient
      .post<any>(
        `${config.apiBaseUrl}/aljabr/user/vehicle/deassignment`,
        obj2,
        {
          headers: this.requestHeader,
        }
      )
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  registerdriver(keys: any, keys2: any): Observable<any> {
    const obj2 = Object.assign({}, keys, keys2, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/driver/registration`, obj2)
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  registersp(keys: any, keys2: any): Observable<any> {
    const obj2 = Object.assign({}, keys, keys2, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/sp/registration`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  registeradmin(keys: any, keys2: any): Observable<any> {
    const obj2 = Object.assign({}, keys, keys2, this.details.getResponse());
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/admin/add`, obj2, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }

  registervehicle(keys: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': '',
        Authorization: 'Bearer ' + this.store.getToken(),
      }),
    };
    return this.httpClient
      .post<any>(`${config.apiBaseUrl}/aljabr/addDriverVehicleDetails`, keys, {
        headers: this.requestHeader,
      })
      .pipe(
        timeout(6000),
        retry(1),
        catchError((err) => {
          this.ngxLoader.stop();
          this.router.navigate(['/errors']);
          console.error(err);
          return throwError(err);
        })
      );
  }
}
