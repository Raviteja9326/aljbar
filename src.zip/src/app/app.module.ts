import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './commonshare/dashboard/dashboard.component';
import { LoginComponent } from './secure/login/login.component';
import { ForgotpasswdComponent } from './secure/forgotpasswd/forgotpasswd.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import {
  HttpClient,
  HttpClientModule,
  HTTP_INTERCEPTORS,
} from '@angular/common/http';
import {
  NgxUiLoaderConfig,
  NgxUiLoaderModule,
  SPINNER,
  POSITION,
  PB_DIRECTION,
  NgxUiLoaderRouterModule,
  NgxUiLoaderService,
} from 'ngx-ui-loader';
import { ErrorComponent } from './commonshare/error/error.component';
import { SearchComponent } from './commonshare/search/search.component';
import { MaterialModule } from './commonshare/material.module';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { TwoDigitDecimaNumberDirective } from './commonshare/TwoDigitDecimaNumber.directive';
import { AuthInterceptor } from './core/interceptor/auth.interceptor';
import { TableModule } from 'primeng/table';
import { ResetpwdComponent } from './secure/resetpwd/resetpwd.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

const ngxUiLoaderConfig: NgxUiLoaderConfig = {
  bgsColor: 'rgba(255,255,255,0.5)',
  bgsOpacity: 0.5,
  bgsPosition: 'bottom-right',
  bgsSize: 30,
  bgsType: 'three-bounce',
  blur: 5,
  delay: 0,
  fastFadeOut: true,
  fgsColor: '#fcde20',
  fgsPosition: 'center-center',
  fgsSize: 30,
  fgsType: 'three-bounce',
  gap: 24,
  logoPosition: 'center-center',
  logoSize: 120,
  logoUrl: 'assets/img/favicon.png',
  masterLoaderId: 'master',
  overlayBorderRadius: '0',
  overlayColor: 'rgba(40, 40, 40, 0.8)',
  pbColor: '#fcde20',
  pbDirection: 'ltr',
  pbThickness: 3,
  hasProgressBar: false,
  text: 'Please wait loading',
  textColor: '#FFFFFF',
  textPosition: 'center-center',
  maxTime: -1,
  minTime: 300,
};

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LoginComponent,
    ForgotpasswdComponent,
    ErrorComponent,
    SearchComponent,
    TwoDigitDecimaNumberDirective,
    ResetpwdComponent,
  ],
  imports: [
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    BrowserAnimationsModule,
    MaterialModule,
    InfiniteScrollModule,
    BrowserModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    TableModule,
    NgxSkeletonLoaderModule,
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
