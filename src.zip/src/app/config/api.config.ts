export const config = {
  /**
   * This Files Defines the URL FOr Consuming the API
   */
  // BaseUrl Of The BackEnd API Data
  apiBaseUrl: 'https://support.mrmusllaha.com/v1',
  imgprof: 'https://images.mrmusllaha.com/profile/',
  imgdoc: 'https://documents.mrmusllaha.com/partner/',
};
