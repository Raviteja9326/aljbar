import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import { TranslateService } from '@ngx-translate/core';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import Swal from 'sweetalert2';

export function MustMatch(controlName: string, matchingControlName: string) {
  return (updateforgotpasswordform: FormGroup) => {
    const control = updateforgotpasswordform.controls[controlName];
    const matchingControl =
      updateforgotpasswordform.controls[matchingControlName];

    if (matchingControl.errors && !matchingControl.errors.mustMatch) {
      // return if another validator has already found an error on the matchingControl
      return;
    }

    // set error on matchingControl if validation fails
    if (control.value !== matchingControl.value) {
      matchingControl.setErrors({ mustMatch: true });
    } else {
      matchingControl.setErrors(null);
    }
  };
}

@Component({
  selector: 'app-resetpwd',
  templateUrl: './resetpwd.component.html',
  styleUrls: ['./resetpwd.component.scss'],
})
export class ResetpwdComponent implements OnInit, OnDestroy {
  errormsgdisplay2: boolean = false;
  errormsgdisplay: boolean = false;
  errormsg: any;
  fieldTextType: boolean = false;
  fieldTextType2: boolean = false;
  ip!: string;
  long!: string;
  latt!: string;
  betters: boolean = false;
  better: boolean = false;
  destroy$: Subject<boolean> = new Subject<boolean>();
  skeletonloader: boolean = false;
  id: any;

  constructor(
    private login: LoginService,
    private fb: FormBuilder,
    private ngxLoader: NgxUiLoaderService,
    private useservice: AllinoneService,
    private routes: ActivatedRoute,
    private router: Router,
    private translateService: TranslateService,
    private userAuthService: StorageService
  ) {
    this.translateService.setDefaultLang('en');
    this.useservice.ipaddress.subscribe((res) => {
      this.ip = res;
      console.log(this.ip);
    });
    this.useservice.longitude.subscribe((res) => {
      this.long = res;
    });
    this.useservice.latitude.subscribe((res) => {
      this.latt = res;
    });
  }

  ngOnInit(): void {
    this.id = this.routes.snapshot.params['id'];
  }

  selectmethod(val) {
    this.translateService.use(val).toPromise();
    this.useservice.changlang(val);
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  toggleFieldTextType2() {
    this.fieldTextType2 = !this.fieldTextType2;
  }

  loginform = new FormGroup({
    newCred: new FormControl('', [
      Validators.required,
      Validators.maxLength(16),
      Validators.pattern(
        /^(?=.*\d)(?=.*[\~\!\@\#\$\%\^\&\*\)\(\_\+\-\:\[\}\=\"\`])(?=.*[a-z])(?=.*[A-Z]).{8,}$/
      ),
    ]),
    conformCred: new FormControl('', [
      Validators.required,
      Validators.maxLength(16),
      Validators.pattern(
        /^(?=.*\d)(?=.*[\~\!\@\#\$\%\^\&\*\)\(\_\+\-\:\[\}\=\"\`])(?=.*[a-z])(?=.*[A-Z]).{8,}$/
      ),
    ]),
  });

  get fixit() {
    return this.loginform.controls;
  }

  LoginUser() {
    this.skeletonloader = true;
    const keys: any = {};
    keys['iPAddress'] = this.ip;
    keys['latitude'] = this.latt;
    keys['longitude'] = this.long;
    keys['language'] = 'en';
    keys['verifyKey'] = this.id;
    this.login
      .resetpwd(keys, this.loginform.value)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        this.ngxLoader.stopAll();
        if (data['status'] == '1005') {
          this.useservice.setblur('noblur');
          this.skeletonloader = false;
          const Toast = Swal.mixin({
            toast: true,
            position: 'center-right',
            showConfirmButton: false,
            timer: 6000,
          });
          Toast.fire({
            icon: 'warning',
            title: `password was changed successfully, please login again`,
          });
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 6000);
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.better = this.useservice.allrespnse();
          this.betters = true;
          setTimeout(() => {
            this.betters = false;
          }, 3000);
          this.skeletonloader = false;
          this.useservice.setblur('noblur');
        }
      });
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
