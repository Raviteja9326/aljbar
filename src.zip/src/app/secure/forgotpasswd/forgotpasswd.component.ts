import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import { TranslateService } from '@ngx-translate/core';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import Swal from 'sweetalert2';

export function noWhitespaceValidator(control: FormControl) {
  const isSpace = (control.value || '').match(/\s/g);
  return isSpace ? { whitespace: true } : null;
}
export function spaceValidator(control: AbstractControl) {
  if (control && control.value && !control.value.replace(/\s/g, '').length) {
    control.setValue('');
    console.log(control.value);
    return { required: true };
  } else {
    return null;
  }
}

@Component({
  selector: 'app-forgotpasswd',
  templateUrl: './forgotpasswd.component.html',
  styleUrls: ['./forgotpasswd.component.scss'],
})
export class ForgotpasswdComponent implements OnInit, OnDestroy {
  fieldTextType: boolean = false;
  ip!: string;
  long!: string;
  latt!: string;
  betters: boolean = false;
  better: boolean = false;
  destroy$: Subject<boolean> = new Subject<boolean>();
  skeletonloader: boolean = false;

  constructor(
    private login: LoginService,
    private ngxLoader: NgxUiLoaderService,
    private useservice: AllinoneService,
    private router: Router,
    private translateService: TranslateService,
    private userAuthService: StorageService
  ) {
    this.login.usersession9();
    this.translateService.setDefaultLang('en');
    this.useservice.ipaddress.subscribe((res) => {
      this.ip = res;
      console.log(this.ip);
    });
    this.useservice.longitude.subscribe((res) => {
      this.long = res;
    });
    this.useservice.latitude.subscribe((res) => {
      this.latt = res;
    });
  }

  ngOnInit(): void {}

  selectmethod(val) {
    this.translateService.use(val).toPromise();
    this.useservice.changlang(val);
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  loginform = new FormGroup({
    emailId: new FormControl('', [
      Validators.pattern(
        '^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@' +
          '[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$'
      ),
      Validators.required,
    ]),
  });

  get fixit() {
    return this.loginform.controls;
  }

  LoginUser() {
    this.skeletonloader = true;
    const keys: any = {};
    keys['iPAddress'] = this.ip;
    keys['latitude'] = this.latt;
    keys['longitude'] = this.long;
    keys['language'] = 'en';
    this.login
      .updatepwd(keys, this.loginform.value)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        this.ngxLoader.stopAll();
        if (data['status'] == '1005') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'center-right',
            showConfirmButton: false,
            timer: 6000,
          });
          Toast.fire({
            icon: 'warning',
            title: `if we have an account for the email address you provided, we have emailed a link to reset your password. The link will be valid for 15 minutes.`,
          });
          this.useservice.setblur('noblur');
          this.skeletonloader = false;
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 6000);
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.better = this.useservice.allrespnse();
          this.betters = true;
          setTimeout(() => {
            this.betters = false;
          }, 3000);
          this.skeletonloader = false;
          this.useservice.setblur('noblur');
        }
      });
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
