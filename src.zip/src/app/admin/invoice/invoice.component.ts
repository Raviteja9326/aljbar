import {
  Component,
  Inject,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SearchComponent } from 'src/app/commonshare/search/search.component';
import { config } from 'src/app/config/api.config';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss'],
})
export class InvoiceComponent implements OnInit, OnDestroy {
  destroy$: Subject<boolean> = new Subject<boolean>();
  url: any = config;
  Object = Object;
  celeb: any = [];
  loading: boolean;
  datafound: any = true;
  page = 0;
  errmsg: boolean = false;
  errmsgdisplay: any;
  datafound2: boolean;
  panelOpenState = false;

  constructor(
    private driver: AdminService,
    public dialog: MatDialog,
    private route: Router,
    private userservice: AllinoneService,
    private store: StorageService,
    private formBuilder: FormBuilder,
    private ngxLoader: NgxUiLoaderService,
    private log: LoginService
  ) {
    this.userservice.setblur('noblur');
    this.ngxLoader.stopAll();
  }

  ngOnInit(): void {
    this.getlist();
  }

  selectform = this.formBuilder.group({
    resetselect: [''],
  });

  openCelebModal(item: any): void {
    var data: boolean = true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: '100%',
      data: {
        invoicedetails: item,
        invoicedetails_bool: data,
      },
      disableClose: true,
      position: {
        top: '20px',
      },
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      this.selectform.controls.resetselect.patchValue('Select');
      this.userservice.setblur('noblur');
      this.ngxLoader.stop();
      this.getlist();
    });
  }

  openCelebModal4(item: any): void {}

  getlist() {
    this.errmsg = false;
    this.userservice.setblur('blur');
    this.ngxLoader.start();
    this.celeb = [];
    const keys: any = {};
    keys['pageNumber'] = this.page.toString();
    keys['pageSize'] = '2000';
    keys['deviceId'] = this.userservice.visitorId;
    keys['city'] = this.store.getvariable();
    this.driver
      .Getinvoicelist(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1069' && data['tokenStatus'] == '1008') {
          this.celeb = data.list;
          this.datafound = false;
          this.datafound2 = true;
          this.errmsg = false;
          this.userservice.setblur('noblur');
          this.ngxLoader.stop();
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.log.usersession8();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.log.usersession8();
        } else if (data['status'] == '1070' && data['tokenStatus'] == '1008') {
          this.celeb = [];
          this.errmsg = true;
          this.errmsgdisplay = 'no record found';
          this.userservice.setblur('noblur');
          this.ngxLoader.stop();
        } else if (data['status']) {
          this.userservice.getallres = data['status'];
          this.errmsgdisplay = this.userservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.userservice.setblur('noblur');
          this.ngxLoader.stop();
        }
      });
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
