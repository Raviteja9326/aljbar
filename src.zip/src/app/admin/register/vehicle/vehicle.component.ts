import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.scss'],
})
export class VehicleComponent implements OnInit, OnDestroy {
  destroy$: Subject<boolean> = new Subject<boolean>();
  errmsg: boolean;
  errmsgdisplay: any;
  constructor(
    private ngxLoader: NgxUiLoaderService,
    private formBuilder: FormBuilder,
    private router: Router,
    private useservice: AllinoneService,
    private logins: LoginService,
    private admin: AdminService,
    private store: StorageService
  ) {
    this.useservice.setblur('noblur');
    this.ngxLoader.stopAll();
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  form = this.formBuilder.group({
    registrationNumber: new FormControl('', [Validators.required]),
    ownerShip: new FormControl('', [Validators.required]),
    vehicleType: new FormControl('', [Validators.required]),
    seater: new FormControl('', [Validators.required]),
    fuelType: new FormControl('', [Validators.required]),
    modelName: new FormControl('', [Validators.required]),
    brand: new FormControl('', [Validators.required]),
    color: new FormControl('', [Validators.required]),
    partnerType: new FormControl('ALJABR', [Validators.required]),
    vinNumber: new FormControl('', [Validators.required]),
  });

  get Controllers() {
    return this.form.controls;
  }

  ngOnInit(): void {}

  reset() {
    this.form.reset();
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  submit() {
    this.errmsg = false;
    this.useservice.setblur('blur');
    this.ngxLoader.start();
    var f = new File([''], 'filename');
    const formData = new FormData();
    formData.append('partnerType', 'ALJABR');
    formData.append('registrationImage', f);
    formData.append('additionalImages', f);
    formData.append('registrationNumber', this.form.value.registrationNumber);
    formData.append('ownerShip', this.form.value.ownerShip);
    formData.append('vehicleType', this.form.value.vehicleType);
    formData.append('seater', this.form.value.seater);
    formData.append('fuelType', this.form.value.fuelType);
    formData.append('modelName', this.form.value.modelName);
    formData.append('brand', this.form.value.brand);
    formData.append('color', this.form.value.color);
    formData.append('vinNumber', this.form.value.vinNumber);
    this.admin
      .registervehicle(formData)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'success',
            title: `Vehicle Successfully Registered`,
          });
          this.router.navigate(['/aljabr/vehiclelist']);
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
        }
      });
  }
}
