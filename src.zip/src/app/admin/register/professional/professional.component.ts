import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-professional',
  templateUrl: './professional.component.html',
  styleUrls: ['./professional.component.scss'],
})
export class ProfessionalComponent implements OnInit, OnDestroy {
  destroy$: Subject<boolean> = new Subject<boolean>();
  errmsg: boolean;
  errmsgdisplay: any;
  citys: any;
  constructor(
    private ngxLoader: NgxUiLoaderService,
    private formBuilder: FormBuilder,
    private router: Router,
    private useservice: AllinoneService,
    private logins: LoginService,
    private admin: AdminService,
    private store: StorageService
  ) {
    this.useservice.setblur('noblur');
    this.ngxLoader.stopAll();
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  cityform = this.formBuilder.group({
    countryName: ['SaudiArabia'],
  });

  form = this.formBuilder.group({
    name: new FormControl('', [Validators.required]),
    emailId: new FormControl('', [Validators.required]),
    mobileNo: new FormControl('', [Validators.required]),
    postalCode: new FormControl('', [Validators.required]),
    country: new FormControl('SaudiArabia', [Validators.required]),
    countryCode: new FormControl('SA'),
    city: new FormControl('', [Validators.required]),
    state: new FormControl('NA'),
    address1: new FormControl('', [Validators.required]),
    address2: new FormControl('', [Validators.required]),
    address3: new FormControl('', [Validators.required]),
    latitude: new FormControl(''),
    longitude: new FormControl(''),
  });

  get Controllers() {
    return this.form.controls;
  }

  ngOnInit(): void {
    this.city();
  }

  reset() {
    this.form.reset();
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  submit() {
    this.errmsg = false;
    this.useservice.setblur('blur');
    this.ngxLoader.start();
    const keys: any = {};
    keys['mobileNo'] = '966' + this.form.value.mobileNo;
    this.admin
      .registersp(this.form.value, keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'success',
            title: `Professional Successfully Registered`,
          });
          this.router.navigate(['/aljabr/professionallist']);
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
        }
      });
  }

  city() {
    this.errmsg = false;
    const keys: any = {};
    keys['type'] = 'GETCITES';
    keys['countryName'] = this.cityform.value.countryName;
    this.admin
      .GetcityList(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1069' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
          this.citys = data.cites_list;
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['status'] == '1070' && data['tokenStatus'] == '1008') {
          this.citys = [];
          this.useservice.setblur('noblur');
          this.ngxLoader.stop();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
        }
      });
  }
}
