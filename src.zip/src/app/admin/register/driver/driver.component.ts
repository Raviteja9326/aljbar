import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SearchComponent } from 'src/app/commonshare/search/search.component';
import { config } from 'src/app/config/api.config';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-driver',
  templateUrl: './driver.component.html',
  styleUrls: ['./driver.component.scss'],
})
export class DriverComponent implements OnInit, OnDestroy {
  url: any = config;
  destroy$: Subject<boolean> = new Subject<boolean>();
  errmsg: boolean;
  errmsgdisplay: any;
  citys: any;
  showdriver: boolean = false;
  cabdata: any = '';
  constructor(
    private ngxLoader: NgxUiLoaderService,
    private formBuilder: FormBuilder,
    private router: Router,
    private useservice: AllinoneService,
    private logins: LoginService,
    private admin: AdminService,
    public dialog: MatDialog
  ) {
    this.useservice.setblur('noblur');
    this.ngxLoader.stopAll();
  }

  form = this.formBuilder.group({
    customerName: new FormControl('', [Validators.required]),
    gender: new FormControl('', [Validators.required]),
    emailid: new FormControl('', [Validators.required]),
    mobileNumber: new FormControl('', [Validators.required]),
    language: new FormControl('', [Validators.required]),
    customerStreet: new FormControl('', [Validators.required]),
    countryCode: new FormControl('SA'),
    customerType: new FormControl('', [Validators.required]),
    resetselect: new FormControl('', [Validators.required]),
  });

  get Controllers() {
    return this.form.controls;
  }

  cityform = this.formBuilder.group({
    countryName: ['SaudiArabia'],
  });

  ngOnInit(): void {
    this.city();
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  reset() {
    this.form.reset();
    this.showdriver = false;
    this.form.controls.resetselect.patchValue('Select');
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  openCelebModal(): void {
    if (this.form.value.mobileNumber == '') {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 4000,
      });
      Toast.fire({
        icon: 'warning',
        title: `Please enter mobile number to assign Vehicle`,
      });
      this.form.controls.resetselect.patchValue('Select');
    } else if (this.form.value.mobileNumber != '') {
      var data: boolean = true;
      const dialogRef = this.dialog.open(SearchComponent, {
        width: '100%',
        data: {
          assignwork_register_bool: data,
          mobile_no: this.form.value.mobileNumber,
        },
        disableClose: true,
        position: {
          top: '20px',
        },
      });
      dialogRef.afterClosed().subscribe((result: any) => {
        if (result != undefined || '') {
          console.log(result.data);
          this.cabdata = result.data;
          this.showdriver = true;
          this.form.controls.resetselect.patchValue('Select');
          this.useservice.setblur('noblur');
          this.ngxLoader.stop();
        } else {
          this.useservice.setblur('noblur');
          this.ngxLoader.stop();
          this.form.controls.resetselect.patchValue('Select');
        }
      });
    }
  }

  hidedriver() {
    this.showdriver = false;
    this.cabdata = '';
  }

  submit() {
    if (this.cabdata == '' || undefined) {
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 4000,
      });
      Toast.fire({
        icon: 'warning',
        title: `Please assign vehicle`,
      });
    } else if (this.cabdata != '' || undefined) {
      this.errmsg = false;
      this.useservice.setblur('blur');
      this.ngxLoader.start();
      const keys: any = {};
      keys['mobileNumber'] = '966' + this.form.value.mobileNumber;
      keys['vehicleId'] = this.cabdata.cabId.toString();
      this.admin
        .registerdriver(this.form.value, keys)
        .pipe(takeUntil(this.destroy$))
        .subscribe((data: any) => {
          if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
            this.ngxLoader.stop();
            this.useservice.setblur('noblur');
            const Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 4000,
            });
            Toast.fire({
              icon: 'success',
              title: `Driver Successfully Registered`,
            });
            this.router.navigate(['/aljabr/driverslist']);
          } else if (
            data['tokenStatus'] == '1009' ||
            data['tokenStatus'] == '1059' ||
            data['tokenStatus'] == '1007' ||
            data['status'] == '1007'
          ) {
            const Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 4000,
            });

            Toast.fire({
              icon: 'warning',
              title: 'sorry for the inconvenience, your session has expired',
            });
            this.logins.usersession8();
          } else if (data['tokenStatus'] == '1187') {
            const Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 4000,
            });

            Toast.fire({
              icon: 'warning',
              title:
                'sorry for the inconvenience, Someone has login with your credentials',
            });
            this.logins.usersession8();
          } else if (data['status']) {
            this.useservice.getallres = data['status'];
            this.errmsgdisplay = this.useservice.allrespnse();
            const Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 4000,
            });
            Toast.fire({
              icon: 'warning',
              title: `${this.errmsgdisplay}`,
            });
            this.ngxLoader.stop();
            this.useservice.setblur('noblur');
          }
        });
    }
  }

  city() {
    this.errmsg = false;
    const keys: any = {};
    keys['type'] = 'GETCITES';
    keys['countryName'] = this.cityform.value.countryName;
    this.admin
      .GetcityList(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1069' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
          this.citys = data.cites_list;
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.logins.usersession8();
        } else if (data['status'] == '1070' && data['tokenStatus'] == '1008') {
          this.citys = [];
          this.useservice.setblur('noblur');
          this.ngxLoader.stop();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.logins.usersession8();
        } else if (data['status']) {
          this.useservice.getallres = data['status'];
          this.errmsgdisplay = this.useservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.useservice.setblur('noblur');
        }
      });
  }
}
