import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SearchComponent } from 'src/app/commonshare/search/search.component';
import { config } from 'src/app/config/api.config';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss'],
})
export class BookingComponent implements OnInit, OnDestroy {
  url: any = config;
  search: boolean = true;
  destroy$: Subject<boolean> = new Subject<boolean>();
  celeb: any = [];
  loading: boolean = true;
  datafound: any = false;
  datafound2: any = false;
  datafound3: any = true;
  errmsg: boolean = false;
  aljbprice: boolean = false;
  selecttype: boolean;
  selectaddon: boolean;
  errmsgdisplay: any;
  isLinear = false;
  page = 0;
  keydata: string;
  assignpend: string;
  oldadd: boolean = true;
  choices: string[] = ['RedClass', 'YellowClass'];
  selectedChoice: any;
  selectedChoice2: any;
  Object = Object;
  searchText: any;
  constructor(
    private ngxLoader: NgxUiLoaderService,
    public ischeck: LoginService,
    private admin: AdminService,
    private getid: AllinoneService,
    private log: LoginService,
    private store: StorageService,
    public dialog: MatDialog
  ) {
    this.selectedChoice = this.choices[0];
    this.getid.setblur('blur');
    this.ngxLoader.stopAll();
  }

  ngOnInit(): void {
    if (
      this.store.getRoles() == 'AljabrSupport' ||
      this.store.getRoles() == 'AljabrManager' ||
      this.store.getRoles() == 'MusllahaAljabrManager'
    ) {
      this.getlist('NEW');
    } else if (this.store.getRoles() == 'AljabrApprover') {
      this.getlist('WAITING_FOR_APPROVAL');
    }
  }

  serchdata(data: any) {
    if (data == 'open') {
      this.search = false;
    } else if (data == 'close') {
      this.search = true;
    }
  }

  selectdata(data: any) {
    this.getid.setblur('blur');
    if (data == 'NEW') {
      this.keydata = data;
      this.searchText = '';
      this.search = true;
      this.getlist(data);
    } else if (data == 'WAITING_FOR_QUOTATION') {
      this.keydata = data;
      this.searchText = '';
      this.search = true;
      this.getlist(data);
    } else if (data == 'WAITING_FOR_APPROVAL') {
      this.keydata = data;
      this.search = true;
      this.getlist(data);
    } else if (data == 'WAITING_FOR_PARTS') {
      this.keydata = data;
      this.search = true;
      this.getlist(data);
    } else if (data == 'WORKING_IN_PROGRESS') {
      this.keydata = data;
      this.getlist(data);
    } else if (data == 'READY_FOR_DELIVER') {
      this.keydata = data;
      this.search = true;
      this.searchText = '';
      this.getlist(data);
    } else if (data == 'WAITING_FOR_ADDITIONAL_APPROVAL') {
      this.keydata = data;
      this.search = true;
      this.getlist(data);
    } else if (data == 'WAITING_FOR_ADDITIONAL_PARTS') {
      this.keydata = data;
      this.search = true;
      this.searchText = '';
      this.getlist(data);
    } else if (data == 'DELIVERED') {
      this.keydata = data;
      this.search = true;
      this.searchText = '';
      this.getlist(data);
    }
  }

  getlist(dataobj: any) {
    this.keydata = dataobj;
    this.datafound = false;
    this.datafound2 = false;
    this.datafound3 = true;
    this.aljbprice = false;
    this.errmsg = false;
    this.getid.setblur('blur');
    this.ngxLoader.start();
    const keys: any = {};
    keys['pageNumber'] = this.page.toString();
    keys['pageSize'] = '2000';
    keys['deviceId'] = this.getid.visitorId;
    keys['bookingStatus'] = dataobj;
    keys['city'] = this.store.getvariable();
    this.admin
      .GetserviceList(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1069' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.getid.setblur('noblur');
          this.datafound = true;
          this.celeb = data.bookingList;
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.log.usersession8();
        } else if (data['status'] == '1070') {
          this.celeb = [];
          this.errmsg = true;
          this.datafound = false;
          this.errmsgdisplay = 'data not available';
          this.ngxLoader.stop();
          this.getid.setblur('noblur');
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.log.usersession8();
        } else if (data['status']) {
          this.getid.getallres = data['status'];
          this.errmsgdisplay = this.getid.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.getid.setblur('noblur');
        }
      });
  }
  delete(obj: any) {
    const keys: any = {};
    keys['bookingId'] = obj.bookingId.toString();
    keys['bookingStatus'] = 'CANCELED';
    keys['professionalId'] = '';
    keys['deviceId'] = this.getid.visitorId;
    Swal.fire({
      title: 'Do you want to cancel the request?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        this.datafound = false;
        this.errmsg = false;
        this.getid.setblur('blur');
        this.ngxLoader.start();
        this.admin
          .updateList(keys)
          .pipe(takeUntil(this.destroy$))
          .subscribe((data: any) => {
            if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
              this.ngxLoader.stop();
              this.getid.setblur('noblur');
              this.getlist(obj.bookingStatus);
              this.datafound = true;
              Swal.fire('Service Cancelled', '', 'success');
            } else if (
              data['tokenStatus'] == '1009' ||
              data['tokenStatus'] == '1059' ||
              data['tokenStatus'] == '1007'
            ) {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });

              Toast.fire({
                icon: 'warning',
                title: 'sorry for the inconvenience, your session has expired',
              });
              this.log.usersession8();
            } else if (data['tokenStatus'] == '1187') {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });

              Toast.fire({
                icon: 'warning',
                title:
                  'sorry for the inconvenience, Someone has login with your credentials',
              });
              this.log.usersession8();
            } else if (data['status']) {
              this.getid.getallres = data['status'];
              this.errmsgdisplay = this.getid.allrespnse();
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });
              Toast.fire({
                icon: 'warning',
                title: `${this.errmsgdisplay}`,
              });
              this.ngxLoader.stop();
              this.getid.setblur('noblur');
            }
          });
      }
    });
  }
  accept(obj) {
    const data = this.celeb.filter((res: any) => {
      return res.bookingId == obj.bookingId;
    });
    this.celeb = data;
    this.datafound2 = true;
    this.datafound3 = false;
    this.aljbprice = true;
    this.searchText = '';
  }

  city(obj: any) {
    var data: boolean = true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: '40%',
      data: {
        workshop: obj,
        workshop_bool: data,
      },
      disableClose: true,
      position: {
        top: '20px',
      },
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      console.log(result);
      this.getlist(result.data);
    });
  }

  estimationprc(obj: any) {
    var data: boolean = true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: '100%',
      data: {
        estmprc: obj,
        estmprc_bool: data,
      },
      disableClose: true,
      position: {
        top: '20px',
      },
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      this.getid.setblur('noblur');
      this.ngxLoader.stop();
    });
  }

  reset(obj: any) {
    this.datafound = true;
    this.datafound2 = false;
    this.datafound3 = true;
    this.aljbprice = false;
    this.getlist(obj);
  }

  escliate(obj: any, obj2: any, obj3: any) {
    if (obj == true) {
      this.assignpend = 'ACCEPTED';
    } else if (obj == false) {
      this.assignpend = 'PENDING';
    }
    this.errmsg = false;
    this.getid.setblur('blur');
    this.ngxLoader.start();
    const keys: any = {};
    keys['bookingId'] = obj3.bookingId.toString();
    keys['deviceId'] = this.getid.visitorId;
    keys['addonstatus'] = this.assignpend;
    keys['bookingStatus'] = obj3.bookingStatus;
    keys['comments'] = obj2.comments;
    this.admin
      .updateList2(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.getid.setblur('noblur');
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.log.usersession8();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.log.usersession8();
        } else if (data['status']) {
          this.getid.getallres = data['status'];
          this.errmsgdisplay = this.getid.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.getid.setblur('noblur');
        }
      });
  }

  newsubmit(obj: any, obj2: any) {
    this.datafound = false;
    this.errmsg = false;
    this.getid.setblur('blur');
    this.ngxLoader.start();
    const keys: any = {};
    keys['bookingId'] = obj.bookingId.toString();
    keys['bookingStatus'] = obj2;
    keys['professionalId'] = obj.proflId;
    keys['deviceId'] = this.getid.visitorId;
    this.admin
      .updateList(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.getid.setblur('noblur');
          this.getlist(obj.bookingStatus);
          Swal.fire('Request Raised, Please Wait', '', 'success');
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.log.usersession8();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.log.usersession8();
        } else if (data['status']) {
          this.getid.getallres = data['status'];
          this.errmsgdisplay = this.getid.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.getid.setblur('noblur');
        }
      });
  }
  escmang(obj: any) {
    const keys: any = {};
    keys['bookingId'] = obj.bookingId.toString();
    keys['deviceId'] = this.getid.visitorId;
    Swal.fire({
      title: 'Do you want to escalate the request?',
      showDenyButton: true,
      showCancelButton: false,
      confirmButtonText: `Yes`,
      denyButtonText: `No`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        this.datafound = false;
        this.errmsg = false;
        this.getid.setblur('blur');
        this.ngxLoader.start();
        this.admin
          .updateList4(keys)
          .pipe(takeUntil(this.destroy$))
          .subscribe((data: any) => {
            if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
              this.ngxLoader.stop();
              this.getid.setblur('noblur');
              this.getlist(obj.bookingStatus);
              this.datafound = true;
              Swal.fire('Your Request Raised To Manager', '', 'success');
            } else if (
              data['tokenStatus'] == '1009' ||
              data['tokenStatus'] == '1059' ||
              data['tokenStatus'] == '1007'
            ) {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });

              Toast.fire({
                icon: 'warning',
                title: 'sorry for the inconvenience, your session has expired',
              });
              this.log.usersession8();
            } else if (data['tokenStatus'] == '1187') {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });

              Toast.fire({
                icon: 'warning',
                title:
                  'sorry for the inconvenience, Someone has login with your credentials',
              });
              this.log.usersession8();
            } else if (data['status']) {
              this.getid.getallres = data['status'];
              this.errmsgdisplay = this.getid.allrespnse();
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });
              Toast.fire({
                icon: 'warning',
                title: `${this.errmsgdisplay}`,
              });
              this.ngxLoader.stop();
              this.getid.setblur('noblur');
            }
          });
      }
    });
  }
  escliate2(obj: any, obj2: any, obj3: any) {
    if (obj == true) {
      this.assignpend = 'ACCEPTED';
    } else if (obj == false) {
      this.assignpend = 'PENDING';
    }
    this.errmsg = false;
    this.getid.setblur('blur');
    this.ngxLoader.start();
    const keys: any = {};
    keys['bookingId'] = obj3.bookingId.toString();
    keys['deviceId'] = this.getid.visitorId;
    keys['subcategoryTypestatus'] = this.assignpend;
    keys['bookingStatus'] = obj3.bookingStatus;
    keys['subcategoryTypeId'] = obj2.subcategoryTypeId;
    this.admin
      .updateList3(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.errmsg = false;
          this.getid.setblur('noblur');
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.log.usersession8();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.log.usersession8();
        } else if (data['status']) {
          this.getid.getallres = data['status'];
          this.errmsgdisplay = this.getid.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.getid.setblur('noblur');
        }
      });
  }

  escliate3(obj: any, obj2: any, obj3: any) {
    if (obj == true) {
      this.assignpend = 'ACCEPTED';
    } else if (obj == false) {
      this.assignpend = 'PENDING';
    }
    this.errmsg = false;
    this.getid.setblur('blur');
    this.ngxLoader.start();
    const keys: any = {};
    keys['bookingId'] = obj3.bookingId.toString();
    keys['deviceId'] = this.getid.visitorId;
    keys['subcategoryTypestatus'] = this.assignpend;
    keys['bookingStatus'] = obj3.bookingStatus;
    keys['subcategoryTypeId'] = obj2.subCategoryTypeId;
    this.admin
      .updateList5(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
          this.ngxLoader.stop();
          this.errmsg = false;
          this.getid.setblur('noblur');
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.log.usersession8();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.log.usersession8();
        } else if (data['status']) {
          this.getid.getallres = data['status'];
          this.errmsgdisplay = this.getid.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.ngxLoader.stop();
          this.getid.setblur('noblur');
        }
      });
  }

  addbool(obj: any) {
    if (obj == 'old') {
      this.oldadd = true;
      this.selectedChoice = this.choices[0];
      this.selectedChoice2 = this.choices[1];
    } else if (obj == 'new') {
      this.oldadd = false;
      this.selectedChoice = this.choices[1];
      this.selectedChoice2 = this.choices[0];
    }
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
