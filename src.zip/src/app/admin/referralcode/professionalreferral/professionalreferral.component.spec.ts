import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfessionalreferralComponent } from './professionalreferral.component';

describe('ProfessionalreferralComponent', () => {
  let component: ProfessionalreferralComponent;
  let fixture: ComponentFixture<ProfessionalreferralComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfessionalreferralComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfessionalreferralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
