import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserreferralComponent } from './userreferral.component';

describe('UserreferralComponent', () => {
  let component: UserreferralComponent;
  let fixture: ComponentFixture<UserreferralComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserreferralComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserreferralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
