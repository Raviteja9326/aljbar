import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { AdminComponent } from './admin.component';
import { AdminRoutingModule } from './admin-routing.module';
import { MatDialogModule } from '@angular/material/dialog';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';
import { MaterialModule } from '../commonshare/material.module';
import { NgxMatMomentModule } from '@angular-material-components/moment-adapter';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { WelcomeComponent } from '../commonshare/welcome/welcome.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { NgxPaginationModule } from 'ngx-pagination';
import { TableModule } from 'primeng/table';
import { BookingComponent } from './booking/booking.component';
import { DriverslistComponent } from './listofdrivers/driverslist/driverslist.component';
import { VehiclelistComponent } from './vehiclelist/vehiclelist.component';
import { SplistComponent } from './listofdrivers/splist/splist.component';
import { DriverComponent } from './register/driver/driver.component';
import { ProfessionalComponent } from './register/professional/professional.component';
import { VehicleComponent } from './register/vehicle/vehicle.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { EscalateComponent } from './escalate/escalate.component';
import { AllbookingsComponent } from './allbookings/allbookings.component';
import { UserreferralComponent } from './referralcode/userreferral/userreferral.component';
import { ProfessionalreferralComponent } from './referralcode/professionalreferral/professionalreferral.component';
import { InvoiceComponent } from './invoice/invoice.component';

const components = [
  AdminComponent,
  WelcomeComponent,
  VehiclelistComponent,
  SplistComponent,
  BookingComponent,
  DriverslistComponent,
];

@NgModule({
  declarations: [
    ...components,
    DriverComponent,
    ProfessionalComponent,
    VehicleComponent,
    EscalateComponent,
    AllbookingsComponent,
    UserreferralComponent,
    ProfessionalreferralComponent,
    InvoiceComponent,
  ],
  imports: [
    Ng2SearchPipeModule,
    TableModule,
    InfiniteScrollModule,
    NgxPaginationModule,
    CommonModule,
    AdminRoutingModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgxMatMomentModule,
    SweetAlert2Module.forRoot(),
    TranslateModule,
  ],
  providers: [DatePipe],
})
export class AdminModule {}
 