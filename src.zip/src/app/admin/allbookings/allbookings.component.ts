import {
  Component,
  Inject,
  OnDestroy,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SearchComponent } from 'src/app/commonshare/search/search.component';
import { config } from 'src/app/config/api.config';
import { StorageService } from 'src/app/core/interceptor/storage.service';
import { AdminService } from 'src/app/services/admin.service';
import { AllinoneService } from 'src/app/services/allinone.service';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-allbookings',
  templateUrl: './allbookings.component.html',
  styleUrls: ['./allbookings.component.scss'],
})
export class AllbookingsComponent implements OnInit, OnDestroy {
  destroy$: Subject<boolean> = new Subject<boolean>();
  url: any = config;
  Object = Object;
  celeb: any = [];
  loading: boolean;
  datafound: any = true;
  page = 0;
  errmsg: boolean = false;
  errmsgdisplay: any;
  datafound2: boolean;
  panelOpenState = false;

  constructor(
    private driver: AdminService,
    public dialog: MatDialog,
    private route: Router,
    private userservice: AllinoneService,
    private store: StorageService,
    private formBuilder: FormBuilder,
    private ngxLoader: NgxUiLoaderService,
    private log: LoginService
  ) {
    this.userservice.setblur('noblur');
    this.ngxLoader.stopAll();
  }

  ngOnInit(): void {
    this.getlist();
  }

  selectform = this.formBuilder.group({
    resetselect: [''],
  });

  openCelebModal(item: any, datastatus: any): void {
    var data: boolean = true;
    const dialogRef = this.dialog.open(SearchComponent, {
      width: '100%',
      data: {
        assignwork: item,
        assignwork_bool: data,
        assignwork_status: datastatus,
      },
      disableClose: true,
      position: {
        top: '20px',
      },
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      this.selectform.controls.resetselect.patchValue('Select');
      this.userservice.setblur('noblur');
      this.ngxLoader.stop();
      this.getlist();
    });
  }

  openCelebModal4(item: any): void {}

  shownotif() {
    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 5000,
    });
    Toast.fire({
      icon: 'info',
      title: `Driver allocated to vehicle, You can't able to delete, please contact support@mrmusllaha.com`,
    });
  }

  getlist() {
    this.errmsg = false;
    this.userservice.setblur('blur');
    this.ngxLoader.start();
    this.celeb = [];
    const keys: any = {};
    keys['pageNumber'] = this.page.toString();
    keys['pageSize'] = '2000';
    keys['deviceId'] = this.userservice.visitorId;
    keys['city'] = this.store.getvariable();
    this.driver
      .Getpartnerlist(keys)
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data['status'] == '1069' && data['tokenStatus'] == '1008') {
          this.celeb = data.List;
          this.datafound = false;
          this.datafound2 = true;
          this.errmsg = false;
          this.userservice.setblur('noblur');
          this.ngxLoader.stop();
        } else if (
          data['tokenStatus'] == '1009' ||
          data['tokenStatus'] == '1059' ||
          data['tokenStatus'] == '1007' ||
          data['status'] == '1007'
        ) {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title: 'sorry for the inconvenience, your session has expired',
          });
          this.log.usersession8();
        } else if (data['tokenStatus'] == '1187') {
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });

          Toast.fire({
            icon: 'warning',
            title:
              'sorry for the inconvenience, Someone has login with your credentials',
          });
          this.log.usersession8();
        } else if (data['status'] == '1070' && data['tokenStatus'] == '1008') {
          this.celeb = [];
          this.errmsg = true;
          this.errmsgdisplay = 'no record found';
          this.userservice.setblur('noblur');
          this.ngxLoader.stop();
        } else if (data['status']) {
          this.userservice.getallres = data['status'];
          this.errmsgdisplay = this.userservice.allrespnse();
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
          });
          Toast.fire({
            icon: 'warning',
            title: `${this.errmsgdisplay}`,
          });
          this.userservice.setblur('noblur');
          this.ngxLoader.stop();
        }
      });
  }

  deletedriver(id: any) {
    Swal.fire({
      title: `Are you sure to delete?`,
      input: 'textarea',
      html: `<div style="text-align: left; padding-top: 25px;">Please comment out below :</div>`,
      showClass: {
        popup: 'animate__animated animate__fadeInDown',
      },
      hideClass: {
        popup: 'animate__animated animate__fadeOutUp',
      },
      confirmButtonText: 'Submit',
      showCancelButton: true,
      customClass: {
        validationMessage: 'my-validation-message',
      },
      preConfirm: (value) => {
        if (!value) {
          Swal.showValidationMessage('You need to comment');
        }
      },
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        const keys: any = {};
        keys['mobileNumber'] = id.toString();
        keys['comments'] = `${result.value}`;
        keys['deviceId'] = this.userservice.visitorId;
        this.errmsg = false;
        this.userservice.setblur('blur');
        this.ngxLoader.start();
        this.driver
          .driverdelete(keys)
          .pipe(takeUntil(this.destroy$))
          .subscribe((data: any) => {
            console.log(data);
            if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });
              Toast.fire({
                icon: 'success',
                title: `Sucessfully deleted`,
              });
              this.userservice.setblur('noblur');
              this.ngxLoader.stop();
              this.getlist();
            } else if (
              data['tokenStatus'] == '1009' ||
              data['tokenStatus'] == '1059' ||
              data['tokenStatus'] == '1007'
            ) {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });
              Toast.fire({
                icon: 'warning',
                title: 'sorry for the inconvenience, your session has expired',
              });
              this.log.usersession8();
            } else if (data['tokenStatus'] == '1187') {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });

              Toast.fire({
                icon: 'warning',
                title:
                  'sorry for the inconvenience, Someone has login with your credentials',
              });
              this.log.usersession8();
            } else if (data['status']) {
              this.userservice.getallres = data['status'];
              this.errmsgdisplay = this.userservice.allrespnse();
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });
              Toast.fire({
                icon: 'warning',
                title: `${this.errmsgdisplay}`,
              });
              this.userservice.setblur('noblur');
              this.ngxLoader.stop();
            }
          });
      }
    });
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  workshop(val: any, mob: any) {
    if (val == 'Assign') {
      this.openCelebModal(mob, val);
    } else if (val == 'Re-Assign') {
      this.openCelebModal(mob, val);
    } else if (val == 'De-Assign') {
      this.deassignstatus(mob);
    }
  }

  deassignstatus(id: any) {
    Swal.fire({
      title: `Are You Sure To De-Assign the Vehicle?`,
      input: 'textarea',
      html: `<div style="text-align: left; padding-top: 25px;">Please comment out below :</div>`,
      showClass: {
        popup: 'animate__animated animate__fadeInDown',
      },
      hideClass: {
        popup: 'animate__animated animate__fadeOutUp',
      },
      confirmButtonText: 'Submit',
      showCancelButton: true,
      customClass: {
        validationMessage: 'my-validation-message',
      },
      preConfirm: (value) => {
        if (!value) {
          Swal.showValidationMessage('You need to comment');
        }
      },
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        const keys: any = {};
        keys['mobile'] = id.toString();
        keys['comments'] = `${result.value}`;
        keys['deviceId'] = this.userservice.visitorId;
        this.errmsg = false;
        this.userservice.setblur('blur');
        this.ngxLoader.start();
        this.driver
          .deassignVehicle(keys)
          .pipe(takeUntil(this.destroy$))
          .subscribe((data: any) => {
            console.log(data);
            if (data['status'] == '1005' && data['tokenStatus'] == '1008') {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });
              Toast.fire({
                icon: 'success',
                title: `Sucessfully Vehicle De-Assign`,
              });
              this.userservice.setblur('noblur');
              this.ngxLoader.stop();
              this.getlist();
            } else if (
              data['tokenStatus'] == '1009' ||
              data['tokenStatus'] == '1059' ||
              data['tokenStatus'] == '1007'
            ) {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });
              Toast.fire({
                icon: 'warning',
                title: 'sorry for the inconvenience, your session has expired',
              });
              this.log.usersession8();
            } else if (data['tokenStatus'] == '1187') {
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });

              Toast.fire({
                icon: 'warning',
                title:
                  'sorry for the inconvenience, Someone has login with your credentials',
              });
              this.log.usersession8();
            } else if (data['status']) {
              this.userservice.getallres = data['status'];
              this.errmsgdisplay = this.userservice.allrespnse();
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 4000,
              });
              Toast.fire({
                icon: 'warning',
                title: `${this.errmsgdisplay}`,
              });
              this.userservice.setblur('noblur');
              this.ngxLoader.stop();
            }
          });
      } else {
        this.selectform.controls.resetselect.patchValue('Select');
      }
    });
  }
}
