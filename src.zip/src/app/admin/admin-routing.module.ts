import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { WelcomeComponent } from '../commonshare/welcome/welcome.component';
import { BookingComponent } from './booking/booking.component';
import { DriverslistComponent } from './listofdrivers/driverslist/driverslist.component';
import { VehiclelistComponent } from './vehiclelist/vehiclelist.component';
import { SplistComponent } from './listofdrivers/splist/splist.component';
import { DriverComponent } from './register/driver/driver.component';
import { ProfessionalComponent } from './register/professional/professional.component';
import { VehicleComponent } from './register/vehicle/vehicle.component';
import { EscalateComponent } from './escalate/escalate.component';
import { AllbookingsComponent } from './allbookings/allbookings.component';
import { UserreferralComponent } from './referralcode/userreferral/userreferral.component';
import { ProfessionalreferralComponent } from './referralcode/professionalreferral/professionalreferral.component';
import { InvoiceComponent } from './invoice/invoice.component';

const adminroutes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: 'welcome',
        component: WelcomeComponent,
      },
      {
        path: 'services',
        component: BookingComponent,
      },
      {
        path: 'driverslist',
        component: DriverslistComponent,
      },
      {
        path: 'vehiclelist',
        component: VehiclelistComponent,
      },
      {
        path: 'professionallist',
        component: SplistComponent,
      },
      {
        path: 'vehicleregistration',
        component: VehicleComponent,
      },
      {
        path: 'professionalregistration',
        component: ProfessionalComponent,
      },
      {
        path: 'driverregistration',
        component: DriverComponent,
      },
      {
        path: 'allescalatelist',
        component: EscalateComponent,
      },
      {
        path: 'allbookinglist',
        component: AllbookingsComponent,
      },
      {
        path: 'userreferrallist',
        component: UserreferralComponent,
      },
      {
        path: 'professionalreferrallist',
        component: ProfessionalreferralComponent,
      },
      {
        path: 'invoicelist',
        component: InvoiceComponent,
      },
    ],
  },
];

@NgModule({
    imports: [RouterModule.forChild(adminroutes)],
    exports: [RouterModule],
})
export class AdminRoutingModule { }
